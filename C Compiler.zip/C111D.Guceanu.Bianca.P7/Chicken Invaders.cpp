﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include <WinBase.h>
#include <conio.h>
#include<time.h>



#define DIM_X 20
#define DIM_Y 60


#define CHR_LEFT_UP 218
#define CHR_LEFT_BOTTOM 192
#define CHR_RIGHT_UP 191
#define CHR_RIGHT_BOTTOM 217
#define CHR_VERTICAL_BAR 179
#define CHR_HORIZONTAL_BAR 196

#define SPACESHIP 30
#define PROJECTILE 94
#define CHICKENS 234
#define CHICKENS_VALUE -22
#define NIVEL 17
#define EGGS 'o'
#define LASER 186
#define BOMB 233
#define BOSS_P 'v'

#define BOSS_LEFT_UP 201
#define BOSS_LEFT_BOTTOM 200
#define BOSS_HORIZONTAL 205
#define BOSS_VERTICAL 186
#define BOSS_RIGHT_UP 187
#define BOSS_RIGHT_BOTTOM 188
#define BOSS 31

#define for_i for(int i=0;i<DIM_X;i++)
#define for_j for(int j=0;j<DIM_Y;j++)

char scene[DIM_X][DIM_Y];
int spaceship_x_old;
int spaceship_y_old;
int spaceship_x_new;
int spaceship_y_new;
int speedspaceship_x = 1;
int speedspaceship_y = 0;
int speed_threshold = 1;
int eggs_x, eggs_y;
bool shoot = false;
bool shootlaser = false;
bool shootdouble = false;
int recharge;
int rechargelaser;
int rechargedouble;
int scor = 0;
bool delete_laser;
int level=1;
char oldscene[DIM_X][DIM_Y];
bool laser_restriction = true;
bool double_restriction = true;

int boss_hp = 30;
int boss_components[7] = { 200,201,205,186,187,188,31 };

int maximum_nr_eggs=0;
int current_nr_eggs = 0;


void red();
void cyan();
void yellow();
void green();
void purple();
void blue();
void white();
void reset();

void fullscreen();
void menu();
void hidecursor();
void gotoXY();

void initialize_scene();
void display_scene();

void initialize_spaceship();
void right();
void left();
void game_keys();
void set_doubleprojectile();
void set_projectile();
void move_projectile_1();
void set_laser();
void move_laser();
void move_eggs();
void generate_eggs();
bool destroy_spaceship();
void set_boss_level(int x);
void clean(int x);
void boss_shoot();
void move_boss_projectile();
void boss_health();
void select_level();
bool next_level();



int main()
{
	int line = 5;
	fullscreen();
	menu();//afisarea meniului initial 
	srand(time(NULL));

	
	
	while (level)//while pentru parcurgerea tuturor nivelelor & intrarea in mod infinit dupa parcurgerea celor 10 nivele
	{
		hidecursor();
		initialize_scene();
		select_level();
		initialize_spaceship();
		display_scene();
		int time = 0;

		while (destroy_spaceship() == false && next_level() == true)//cat timp ouale nu lovesc nava
		{
			move_projectile_1();
			generate_eggs();
			move_eggs();


			if (level == 5)
			{
				boss_shoot();
				move_boss_projectile();
				boss_health();
				if (time >= 35 && boss_hp > 0)
				{
					time = 0;
					clean(line);
					set_boss_level(line + 1);
					line++;
				}
				else if (boss_hp <= 0)
				{
					clean(line);
				}
				time++;

				if (line == 12)
				{
					system("cls");
					printf("\n\n\n\n\n\n\n\n\n\n");
					red();
					printf("\t\t\t\t\t\tOOPS!GAME OVER!\n\n");
					printf("\t\t\t\t\t\t FINAL SCORE:%d", scor);
					printf("\n\n\n\n\n\n\n\n\n\n");
					reset();
					exit(0);//iesire completa din joc
				}

				
			}
			Sleep(100);

			display_scene();
			if (delete_laser)
			{
				move_laser();
				delete_laser = false;
			}

			for (int i = 0; i < 1000; i++)
			{
				game_keys();
				set_projectile();
				set_laser();
				set_doubleprojectile();

			}

		}

		if (destroy_spaceship())//if pentru in intrarea in pierderea jocului
		{
			//afisarea mesajului de pierdere a jocului
			system("cls");//curatarea ecranului
			printf("\n\n\n\n\n\n\n\n\n\n");
			red();
			printf("\t\t\t\t\t\tOOPS!GAME OVER!\n\n");
			printf("\t\t\t\t\t\t FINAL SCORE:%d", scor);
			printf("\n\n\n\n\n\n\n\n\n\n");
			reset();
			exit(0);//iesire completa din joc
		}

		level++;//incrementarea nivelelor
		current_nr_eggs = 0;//revenirea la niciun ou dupa terminarea unui nivel
	}

}


//functii pentru colorarea caracterelor
void red() {
	printf("\033[1;31m");
}
void cyan()
{
	printf("\033[1;36m");
}
void yellow()
{
	printf("\033[1;33m");
}
void green()
{
	printf("\033[0;32m");
}
void purple()
{
	printf("\033[0;35m");
}
void blue()
{
	printf("\033[0;34m");
}
void white()
{
	printf("\033[0;37m");
}
void reset()
{
	printf("\033[0m");
}

//functie pentru afisarea jocului pe tot ecranul
void fullscreen()
{
	keybd_event(VK_MENU, 0x38, 0, 0);
	keybd_event(VK_RETURN, 0x1c, 0, 0);
	keybd_event(VK_RETURN, 0x1c, KEYEVENTF_KEYUP, 0);
	keybd_event(VK_MENU, 0x38, KEYEVENTF_KEYUP, 0);
}
//meniu de afisare pentru inceperea jocului
void menu()
{
	COORD cursorPosition;	//functie folosita pentru a curata ecranul care mentine cursivitatea jocului
	cursorPosition.X = 0;
	cursorPosition.Y = 0;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cursorPosition);

	//desenarea meniului de intrare a jocului
	printf("\n\n\n\n\n\n\n\n\n\n");
	red();
	printf("\t\t\t\t\t\tCHICKEN INVADERS\n\n");
	Sleep(1000);
	system("cls");
	printf("\n\n\n\n\n\n\n\n\n\n");
	printf("\t\t\t\t\t   Press 'p' to play the game.");
	while(_getch()!='p'){}
	system("cls");
	printf("\n\n\n\n\n\n\n\n\n\n");
	printf("\t\t\t\t  Press '1' for EASY\n");
	printf("\t\t\t\t  Press '2' for MEDIUM\n");
	printf("\t\t\t\t  Press '3' for HARD\n");
	char option;
	option = _getch();
	switch (option)//dificultatea jocului este contorizata prin numarul de oua care cad intr-un interval de timp din gaini
	{
	      case '1':
			  maximum_nr_eggs = 2;
			  break;
		  case '2':
			  maximum_nr_eggs = 5;
			  break;
		  case '3':
			  maximum_nr_eggs = 8;
			  break;
	}

}
//Functie pentru ascunderea cursorului.
void hidecursor()
{
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO info;
	info.dwSize = 100;
	info.bVisible = FALSE;
	SetConsoleCursorInfo(consoleHandle, &info);
}
//Functie care muta cursorul la pozitia x,y in consola
void gotoXY(int x, int y)
{
	COORD coord = { x, y };

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}


//Functie pentru desenarea chenarului
void initialize_scene()
{
	//intializarea matricii cu spatiu
	for_i
	{
		for_j
		scene[i][j] = ' ';
	}
	//setarea chenarului
	for_j
		scene[0][j] = scene[DIM_X - 1][j] = CHR_HORIZONTAL_BAR;

	for_i
		scene[i][0] = scene[i][DIM_Y - 1] = CHR_VERTICAL_BAR;

	scene[0][0] = CHR_LEFT_UP;
	scene[0][DIM_Y - 1] = CHR_RIGHT_UP;
	scene[DIM_X - 1][0] = CHR_LEFT_BOTTOM;
	scene[DIM_X - 1][DIM_Y - 1] = CHR_RIGHT_BOTTOM;

}
//Functie pentru afisarea scenei
void display_scene()
{
	COORD cursorPosition;//functie folosita pentru a curata ecranul si care rezolva problema cursivitatii 
	cursorPosition.X = 0;
	cursorPosition.Y = 0;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cursorPosition);

	//afisarea scenei impreuna cu elementele sale si culori
	for_i
	{
		for_j
		{
		   if (scene[i][j] == CHICKENS_VALUE)
		   red();
		   else if (scene[i][j] == SPACESHIP)
		   white();
		   else if (scene[i][j] == EGGS)
		   yellow();
		   else if (scene[i][j] == PROJECTILE)
		   purple();
		   else
		   blue();

	      printf("%c", scene[i][j]);
		}
		printf("\n");
	}
	
	cyan();
	//afisarea scorului sub chenar
	printf("SCOR:%d\n", scor);
	//afisarea instructiunilor 
	if (level <= 10)
		printf("LEVEL:%d\n", level);
	else 
		printf("INFINITY MODE\n");

	    


	gotoXY(50, 10);
	printf("\t\tINTRUCTIONS:");
	gotoXY(50, 11);
	printf("\t\tPress 'enter' to shoot!");
	gotoXY(50, 12);
	printf("\t\tPress 'a' and 'd' to move the spaceship.");
	gotoXY(50, 13);
	printf("\t\tPress 'spacebar' to pause the game!");
	gotoXY(50, 14);
	printf("\t\tPress 'x' to stop the game!");
	
	
	if (level >= 2)//afisarea mesajului de posibilitate a utilizarii altor proiectile
	{
		gotoXY(50, 15);
		printf("\t\tPress 'o' double shoot!\n");
	}
	if (level >= 6)
	{
		gotoXY(50, 16);
		printf("\t\tPress 'l' to activate the laser!\n");
	}
	
}

//aceasta functie seteaza nava si ii initializeaza pozitia
void initialize_spaceship()
{
	spaceship_y_old = DIM_Y / 2;
	spaceship_x_old = NIVEL;
	spaceship_y_new = DIM_Y / 2;
	spaceship_x_new = NIVEL;

	scene[spaceship_x_new][spaceship_y_new] = SPACESHIP;
}

//functii pentru deplasarea navei la stanga si la dreapta
void right()
{
	speedspaceship_x = 1;


	if (spaceship_y_new < DIM_Y - 2)
	{
		spaceship_y_new += speedspaceship_x;
		scene[spaceship_x_new][spaceship_y_new] = SPACESHIP;
		scene[spaceship_x_old][spaceship_y_old] = ' ';

		spaceship_y_old = spaceship_y_new;
	}

}
void left()
{
	speedspaceship_x = -1;

	if (spaceship_y_new > 1)
	{
		spaceship_y_new += speedspaceship_x;
		scene[spaceship_x_new][spaceship_y_new] = SPACESHIP;
		scene[spaceship_x_old][spaceship_y_old] = ' ';

		spaceship_y_old = spaceship_y_new;
	}


}
//tastele utilizate in joc
void game_keys()
{
	char ch;
	if (_kbhit())//daca cheia a fost apasata sau nu
	{
		ch = _getch();
		switch (ch)
		{
		case 'a':
			left();
			break;
		case 'd':
			right();
			break;
		case 13://cod ascii pt enter
			shoot = true;
			break;
		case ' ':
			gotoXY(19, 11);//pozitionarea mesajului 
			printf("The game is paused.");
			while (_getch() != ' ') {}
			break;
		case 'x':
			system("cls");
			printf("\n\n\n\n\n\n\n\n\n\n");
			red();
			printf("\t\t\t\t\t\t YOU LEFT THE GAME!\n\n");
			printf("\n\n\n\n\n\n\n\n\n\n");
			reset();
			exit(0);
			break;
		case 'l':

			if (laser_restriction == false)//bool utilizat pentru a activa proiectilul de la un nivel specific
			{
				shootlaser = true;
			}
			break;
		case 'o':
			if (double_restriction == false)
			{
				shootdouble = true;
			}
			break;


		}

	}
}


//functie pentru setarea proiectilului clasic 
void set_projectile()
{

	if (shoot && recharge == 0)
	{
		scene[spaceship_x_new - 1][spaceship_y_new] = PROJECTILE;
		shoot = false;
		recharge = 4000;//face ca tragerea sa fie mai putin rapida
	}
	if (recharge)
	{
		recharge--;
	}
}
//functie pentru setarea proiectilului dublu 
void set_doubleprojectile()
{
	if (shootdouble && rechargedouble == 0)
	{
		scene[spaceship_x_new - 1][spaceship_y_new + 1] = PROJECTILE;
		scene[spaceship_x_new - 1][spaceship_y_new - 1] = PROJECTILE;
		shootdouble = false;
		rechargedouble = 2000;//pune delay intre proiectile
	}

	if (rechargedouble)
	{
		rechargedouble--;
	}
}
//Functie utilizata pentru miscarea celor doua tipuri de proiectile(simplu si dublu)
void move_projectile_1()
{
	for (int i = 1; i < DIM_X - 1; i++)
	{
		for (int j = 1; j < DIM_Y - 1; j++)
		{
			if (scene[i][j] == PROJECTILE)
			{
				scene[i][j] = ' ';
				// Daca proiectilul loveste o gaina
				if (scene[i - 1][j] != ' ')
				{
					if (scene[i - 1][j] == CHICKENS_VALUE)//CHICKENS_VALUE codul citit in memorie pt codul ASCII CHICKENS (cast)
					{
						scene[i - 1][j] = ' ';
						scor += 10;//incrementare scor
					}
					for (int k = 0; k < 7; k++)
					{
						if (scene[i - 1][j] ==(char) boss_components[k])
						{
							boss_hp--;
						}
					}
				}
				else
				{
					scene[i - 1][j] = PROJECTILE;
				}
				if (scene[1][j] == PROJECTILE)
					scene[1][j] = ' ';
			}
		}
	}
}


//functie pentru setarea laser
void set_laser()
{
	int j;
	if (shootlaser && rechargelaser == 0)
	{
		for (j = 1; j < spaceship_x_new; j++)
		{
			if (scene[j][spaceship_y_new] == CHICKENS_VALUE)
				scor+=10;
			scene[j][spaceship_y_new] = LASER;	
			rechargelaser = 2000;
		}
		delete_laser = true;
		shootlaser = false;
	}

	if (rechargelaser)
	{
		rechargelaser--;
	}
}
//deplasarea laserului 
void move_laser()
{
	int j;
	for (j = 1; j < spaceship_x_new; j++)
	{
		scene[j][spaceship_y_new] = ' ';
  	}
	
}


//functie de generare a proiectiilor inamice
void generate_eggs()
{
	for (int i = 1; i < DIM_X - 1; i++)
	{
		for (int j = 1; j < DIM_Y - 1; j++)
		{
			if (scene[i][j] == CHICKENS_VALUE && rand() % 10 == 0)//rand() pentru pozitionarea oualeor in locuri diferite
			{
				bool ExistChicken = false;//asezarea oualeor doar sub gainile care nu mai au altceva dedesubt
				for (int y = 1; y < 10; y++)
				{
					if (scene[i + y][j] == CHICKENS_VALUE)
					{
						ExistChicken = true;
						break;
					}
				}

				if (!ExistChicken && current_nr_eggs <= maximum_nr_eggs)//adaugarea unui nr limita de oua care sa cada in interval
				{
					scene[i + 1][j] = EGGS;
					current_nr_eggs++;
				}
			}
		}
	}
}
//functie pentru deplasarea proiectilelor inamice
void move_eggs()
{
	for (int i = DIM_X - 3; i >= 1; i--)
		for (int j = DIM_Y - 2; j >= 1; j--)
		{
			if (scene[i][j]==EGGS)
			{ 
				scene[i][j] = ' ';
				scene[i + 1][j] = EGGS;
			}
			if (scene[DIM_X-2][j]==EGGS)
			{

				scene[DIM_X - 2][j] = ' ';
				current_nr_eggs--;
			}
		}
}


//functie apelata in main prin care jocul este declarat pierdut
bool destroy_spaceship()
{
	if (scene[spaceship_x_new][spaceship_y_new] != SPACESHIP)
	{
		return true;
	}
	return false;
}


//construirea scenei pentru boss
void set_boss_level(int x)
{

	oldscene[x][24]=scene[x][24] = BOSS_LEFT_UP;
	for(int j=25;j<=35;j++)
	oldscene[x][j]=scene[x][j] = BOSS_HORIZONTAL;
	oldscene[x][36]=scene[x][36] = BOSS_RIGHT_UP;

	oldscene[x+1][24]=scene[x+1][24] = BOSS_LEFT_BOTTOM;
	for (int j = 25; j <= 28; j++)
	oldscene[x+1][j]=scene[x+1][j] = BOSS;
	oldscene[x+1][29]=scene[x+1][29] = BOSS_RIGHT_UP;

	oldscene[x+1][36]=scene[x+1][36] = BOSS_RIGHT_BOTTOM;
	for (int j = 32; j <= 35; j++)
	oldscene[x+1][j]=scene[x+1][j] = BOSS;
	oldscene[x+1][31]=scene[x+1][31] = BOSS_LEFT_UP;

	oldscene[x+2][29]=scene[x+2][29] = BOSS_VERTICAL;
	oldscene[x+3][29]=scene[x+3][29] = BOSS_VERTICAL;
	oldscene[x+4][29]=scene[x+4][29] = BOSS_VERTICAL;
	
	oldscene[x+2][31]=scene[x+2][31] = BOSS_VERTICAL;
	oldscene[x+3][31]=scene[x+3][31] = BOSS_VERTICAL;
	oldscene[x+4][31]=scene[x+4][31] = BOSS_VERTICAL;

    oldscene[x+5][29]=scene[x+5][29] = BOSS_LEFT_BOTTOM;
	oldscene[x+5][31]=scene[x+5][31] = BOSS_RIGHT_BOTTOM;
	oldscene[x+5][30]=scene[x+5][30] = BOSS;

	if (x == 5)
	{
		int j;
		//pozitionare gaini in forma de triunghi
		//in dreapta
		for (j = 38; j < 53; j += 2)
			scene[5][j] = CHICKENS;
		for (j = 39; j < 52; j += 2)
			scene[6][j] = CHICKENS;
		for (j = 40; j < 51; j += 2)
			scene[7][j] = CHICKENS;
		for (j = 41; j < 50; j += 2)
			scene[8][j] = CHICKENS;
		for (j = 42; j < 49; j += 2)
			scene[9][j] = CHICKENS;
		for (j = 43; j < 48; j += 2)
			scene[10][j] = CHICKENS;
		for (j = 44; j < 47; j += 2)
			scene[11][j] = CHICKENS;

		scene[12][45] = CHICKENS;

		//in stanga
		for (j = 8; j < 23; j += 2)
			scene[5][j] = CHICKENS;
		for (j = 9; j < 22; j += 2)
			scene[6][j] = CHICKENS;
		for (j = 10; j < 21; j += 2)
			scene[7][j] = CHICKENS;
		for (j = 11; j < 20; j += 2)
			scene[8][j] = CHICKENS;
		for (j = 12; j < 19; j += 2)
			scene[9][j] = CHICKENS;
		for (j = 13; j < 18; j += 2)
			scene[10][j] = CHICKENS;
		for (j = 14; j < 17; j += 2)
			scene[11][j] = CHICKENS;

		scene[12][15] = CHICKENS;
	}

}
//functie pentru deplasare pe linie a boss-ului
void clean(int x)
{
	oldscene[x][24] = scene[x][24] =' ';
	for (int j = 25; j <= 35; j++)
		oldscene[x][j] = scene[x][j] =' ';
	oldscene[x][36] = scene[x][36] =' ';

	oldscene[x + 1][24] = scene[x + 1][24] = ' ';
	for (int j = 25; j <= 28; j++)
		oldscene[x + 1][j] = scene[x + 1][j] = ' ';
	oldscene[x + 1][29] = scene[x + 1][29] = ' ';

	oldscene[x + 1][36] = scene[x + 1][36] = ' ';
	for (int j = 32; j <= 35; j++)
		oldscene[x + 1][j] = scene[x + 1][j] = ' ';
	oldscene[x + 1][31] = scene[x + 1][31] = ' ';

	oldscene[x + 2][29] = scene[x + 2][29] = ' ';
	oldscene[x + 3][29] = scene[x + 3][29] = ' ';
	oldscene[x + 4][29] = scene[x + 4][29] = ' ';

	oldscene[x + 2][31] = scene[x + 2][31] = ' ';
	oldscene[x + 3][31] = scene[x + 3][31] = ' ';
	oldscene[x + 4][31] = scene[x + 4][31] = ' ';

	oldscene[x + 5][29] = scene[x + 5][29] = ' ';
	oldscene[x + 5][31] = scene[x + 5][31] = ' ';
	oldscene[x + 5][30] = scene[x + 5][30] = ' ';

}
//initializare proiectil boss
void boss_shoot()
{
	for (int i = 0; i < DIM_X; i++)
	{
		for (int j = 0; j < DIM_Y; j++)
		{
			if (scene[i][j] == (char)BOSS)
			{
				if (rand() % 45 == 0)
				{
					scene[i + 1][j] = (char)BOSS_P;
				}
			}
		}
	}
}
//deplasare proiectil
void move_boss_projectile()
{
	for (int i = DIM_X-1; i >1; i--)
	{
		for (int j = 0; j < DIM_Y; j++)
		{
			if (scene[i][j] == (char)BOSS_P)
			{
				if (i == DIM_X - 2)
				{
					scene[i][j] = ' ';
				}
				else
				{
					scene[i][j] = ' ';
					scene[i + 1][j] = (char)BOSS_P;
				}
				
			}
		}
	}
}
//stergerea boss ului dupa cele 30 lovituri ale proiectilului
void boss_health()
{

	if (boss_hp == 0)
	{
	
		for (int i = 1; i < DIM_X - 1; i++)
		{
			for (int j = 1; j < DIM_Y - 1; j++)
			{
				for (int k = 0; k < 7; k++)
				{
					if (scene[i][j] ==(char) boss_components[k])
					{
						scene[i][j] = ' ';
					}
				}
			}

		}
	}

}


//asezarea oualeor in fiecare nivel si adaugarea unor functii speciale pentru racheta de la anumite nivele 
void select_level()
{
	switch (level)
	{
	case 1:
	{ 
		for (int j = 10; j < DIM_Y - 11; j += 5)
			scene[8][j] = CHICKENS;
		break;
	}

	case 2:
	{
		for (int j = 10; j < DIM_Y - 11; j += 2)
			scene[8][j] = CHICKENS;
		
		double_restriction = false;//activarea proiectilelor speciale 

		break;
	}

	case 3:
	{
		for (int j = 10; j < DIM_Y - 11; j += 4)
			for (int i = 6; i <= 8; i += 2)
				scene[i][j] = CHICKENS;

		
		double_restriction = false;
		break;
		
	}

	case 4:
	{
		for (int j = 10; j < DIM_Y - 11; j += 3)
			for (int i = 6; i <= 8; i += 2)
				scene[i][j] = CHICKENS;
	
		double_restriction = false;

		break;
	}

	case 5:
	{
		set_boss_level(5);
		double_restriction = false;
		
		gotoXY(50, 17);
		green();
		printf("\t\tBOSS LEVEL\n");
		reset();

		break;
		
	}

	case 6:
	{
		scor = scor + 1000;
		for (int j = 10; j < DIM_Y - 11; j += 5)
			for (int i = 4; i <= 8; i += 2)
				scene[i][j] = CHICKENS;
		laser_restriction = false;
		double_restriction = false;

		break;
		
	}

	case 7:
	{
		for (int j = 10; j < DIM_Y - 11; j += 3)
			for (int i = 4; i <= 8; i += 2)
				scene[i][j] = CHICKENS;
		laser_restriction = false;
		double_restriction = false;

		break;
	}

	case 8:
	{
		for (int j = 8; j < DIM_Y - 11; j += 2)
			for (int i = 4; i <= 8; i += 2)
				scene[i][j] = CHICKENS;
		laser_restriction = false;
		double_restriction = false;

		break;
	}

	case 9:
	{
		for (int j = 8; j < DIM_Y - 11; j += 3)
			for (int i = 6; i <= 10; i += 2)
				scene[i][j] = CHICKENS;
		double_restriction = false;
		laser_restriction = false;

		break;
		
	}

	case 10:
	default:
	{
		for (int j = 8; j < DIM_Y - 11; j += 2)
			for (int i = 8; i <= 12; i += 2)
				scene[i][j] = CHICKENS;
		double_restriction = false;
		laser_restriction = false;

		break;

	}

  }
}
//bool pentru trecerea la un alt nivel dupa ce au fost omorate toate gainile 
bool next_level()
{
	int ok = 0;
	for (int i = 2; i < DIM_X -5; i ++)
		for (int j = 2; j < DIM_Y - 2; j++)
		{
			if (scene[i][j] !=' ')
				ok = 1;
		}
	if (ok)
		return true;
	else
		return false;
}



