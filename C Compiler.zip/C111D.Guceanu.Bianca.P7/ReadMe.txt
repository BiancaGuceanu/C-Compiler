Chicken Invaders

Regulile jocului:
•Deplasarea navei se efectuează prin apăsarea tastei ‘a‘ pentru 
mutarea la stânga și respectiv tasta  ‘d‘ pentru mutarea la dreapta.

•Pentru a trage cu proiectil în inamici se va apăsa tasta ‘enter’
 -proiectil simplu-, ‘o’ -proiectil dublu activat începând cu nivelul 2 
și ‘l’- laserul care poate fi utilizat începând cu nivelul 6.

•Se va utiliza ‘space’ pentru oprirea temporară a jocului și tasta 
‘x‘ pentru ieșirea completă din joc.

În funcție de nivelul de dificultate ales de către jucător în meniul principal,
numărul de proiectile inamice care se află în joc în același moment diferă astfel:

•EASY: numărul maxim de proiectile inamice în intervalul de timp este 3.
•MEDIUM: numărul maxim de proiectile inamice în intervalul de timp este 6.
•HARD: numărul maxim de proiectile inamice în intervalul de timp este 9.

Apoi, jocul va fi rulat pe toate cele 10 nivele ale sale, iar în cazul terminării
acestora, jocul va intra în ”INFINITY MODE”, care presupune generarea ultimului 
nivel de repetate ori până în momentul în care nava este omorâtă de proiectilul inamic.

Jocul este declarat pierdut doar atunci când proiectilele inamice ating nava.

Implementarea jocului:

Jocul are la bază o singură matrice care este construită ca o scenă cu elementele 
necesare jocului.
Am început cu o funcție pentru desenarea chenarului și apoi am creat o funcție
pentru afișarea întregii scene, cu toate elementele sale, în care am colorat 
elementele jocului și afișat scorul și nivelul la care jucătorul se află.M-am 
folosit de funcția ”gotoXY” pentru a afișa în partea dreaptă a ecranului instrucțiunile.

Nava spațială este alcătuită dintr-un singur caracter și este poziționată în partea de 
jos a chenarului.Am construit două funcții pentru ca aceasta să se poată deplasa pe 
coloane, la stânga -tasta ”a” sau la dreapta -tasta ”d”.Funcția ”game_keys”  conține 
un switch în care sunt implementate toate tastele utilizate în joc.Nava spațială poate 
trage cu trei proiectile diferite: proiectilul clasic -care omoară găina, dar nu și oul- 
proiectilul dublu -care funcționează pe același principiu cu cel clasic- și laserul -care
 omoară atât găina, dar și oul.În funcția pentru mișcarea celor doua proiectile pe linii 
am inclus și cazul în care acestea întâlnesc o găină care este ulterior omorâtă -înlocuită 
cu spațiu -.În cazul laserului, acesta determină dispariția atât a găinilor, cât și a 
proiectilelor inamice, de pe întreaga coloană.Fiecare găină distrusă reprezintă 10 puncte, 
indiferent de proiectil.

Pentru generarea proiectilelor inamice am folosit funcția rand, astfel ouăle vor fi generate 
pe poziții diferite, iar bool-ul ExistChicken este utilizat pentru face să cadă proiectile 
doar din găinile care nu mai au altă gaină la a doua poziție sub ele.Numărul de ouă care se 
pot afla pe scenă în același timp este setat în funcție de nivelul de dificultate ales de 
jucător.Deplasarea acestora se face într-o funcție separată, unde, de asemenea, se decrementează 
și numărul curent de proiectile care se află pe scenă.Am utilizat o funcție de tip bool pe care 
am apelat-o în main pentru cazul în care proiectilul inamic a atins nava, deci jocul trebuie 
declarat pierdut.

Funcția ”select_level” este cea în care am construit propriu zis nivelele într-un switch, 
diferența dintre acestea fiind constituită din poziționarea găinilor în moduri diferite și 
posibilitatea de la anumite nivele de a folosi mai multe tipuri de proiectile.Nivelul este 
declarat terminat în momentul în care toate găinile din scenă au fost omorâte.

Nivelul 5 este de tip BOSS LEVEL, unde în afară de găini, se găsește și o proiecție care 
generează random proiectile ce pot omorî nava și care la un anumit număr de interații coboară 
cu câte o linie.Acest inamic dispare dacă îi sunt aplicate 30 de proiectile de către navă.

În main am apelat funcția menu, care reprezintă meniul initial al jocului, unde se poate 
alege gradul de dificultate al acestuia.Am folosit un while care rulează la infinit, mai 
întâi pe cele 10 nivele construite și apoi prin repetarea nivelului 10 până când nava este 
omorâtă de către proiectilul inamic.În acest while se găsesc si condițiile de creare a 
nivelului 5 și deplasare a proiectilului special.Toate proiectilele sunt, de asemenea, 
apelate în acest while.Funcția bool pentru pierderea jocului este apelată tot aici, prin
care se curăță ecranul și se afisează mesajul final.

Dificultăți:
•Lipsa cursivității jocului pe care am rezolvat-o înlocuind funcția ”system(”cls”)” cu o 
altă funcție predefinită.
•Deplasarea inamicului special, întrucât am construit-o manual și a fost necesar să contruiesc 
alte funcții si să utilizez o variabila pentru a crea efectul de mișcare.
•Reprezentarea proiecțiilor din inamicul special, pentru a simplifica construirea acestora am 
modificat caracterele de unde voiam să pice proiectilul cu unele diferite față de cele utilizate
în construirea inamicului.
•Deplasarea de pe coloana pe care s-a utilizat laserul poate determina o eroare, astfel că rămâne
 acolo până când se revine pe poziția acestuia și se reapasă pe tasta ”l”.

